package com.example.ithenatechdemoapp.responseXml;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "item", strict = false)
public class RssItem
{


    @Element
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Element
    private String category;
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    @Element
    private String pubDate;

    public String getPubDate() {
        return pubDate;
    }

    public void setPubDate(String pubDate) {
        this.pubDate = pubDate;
    }

    @Element
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    @Element
    private String link;

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

   // @Element
  // @Root(name="media:keywords")
   @Element(name = "keywords", required = false)
   private String media;

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }


    @Element(name = "encoded", required = false)
    private String encoded;

    public String getEncoded() {
        return encoded;
    }

    public void setEncoded(String encoded) {
        this.encoded = encoded;
    }


//////////////////////////////////////
@ElementList(inline = true, required = false)
public List<RssMediaContent> content;


    public List<RssMediaContent> getMediaContent() {
        return content;
    }

    public void setMediaContent(List<RssMediaContent> content) {
        this.content = content;
    }



    @Override
    public String toString() {
        return "RssItem [title=" + title + ", category=" + category + ", pubDate=" + pubDate
                + ", description=" + description +   ", link=" + link +     ",media:keywords=" + media +
                ",content:encoded=" + encoded +      ", media:content=" + content +     "]";


    }





}