package com.example.ithenatechdemoapp;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ithenatechdemoapp.responseXml.RssFeed;
import com.example.ithenatechdemoapp.responseXml.RssItem;
import com.example.ithenatechdemoapp.responseXml.RssMediaContent;
import com.example.ithenatechdemoapp.responseXml.RssService;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.simplexml.SimpleXmlConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "https://arabic.cnn.com/api/v1/rss/entertainment/";

    private static Retrofit.Builder builder = new Retrofit.Builder().baseUrl(BASE_URL)
            .addConverterFactory(SimpleXmlConverterFactory.create());

    private static HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor()
            .setLevel(HttpLoggingInterceptor.Level.BODY);

    private static OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

    TextView txtTitle, txtDescription, txtLink, txtTotalCount;
    RecyclerView recyclerView;
    MyListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtTitle = (TextView) findViewById(R.id.txtTitle);
        txtDescription = (TextView) findViewById(R.id.txtDescription);
        txtLink = (TextView) findViewById(R.id.txtLink);
        txtTotalCount = (TextView) findViewById(R.id.txtTotalCount);

        call();

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);

    }


    public void call() {
        httpClient.addInterceptor(loggingInterceptor);
        builder.client(httpClient.build());

        Retrofit retrofit = builder.build();

        RssService rssService = retrofit.create(RssService.class);

        Call<RssFeed> callAsync = rssService.getFeed();

        callAsync.enqueue(new Callback<RssFeed>() {
            @Override
            public void onResponse(Call<RssFeed> call, Response<RssFeed> response) {
                if (response.isSuccessful()) {
                    RssFeed apiResponse = response.body();

                    txtTotalCount.setText(apiResponse.channel.getArticleList().size() + "" + "  items found near you");

                    ArrayList<RssItem> Details = new ArrayList<>();
                    ArrayList<RssMediaContent> InnerDetails = new ArrayList<>();
                    for (int i = 0; i < apiResponse.channel.getArticleList().size(); i++) {
                        RssItem p = new RssItem();
                        RssMediaContent m = new RssMediaContent();
                        p.setTitle(apiResponse.channel.getArticleList().get(i).getTitle());
                        p.setCategory(apiResponse.channel.getArticleList().get(i).getCategory());
                        p.setPubDate(apiResponse.channel.getArticleList().get(i).getPubDate());
                        p.setDescription(apiResponse.channel.getArticleList().get(i).getDescription());
                        p.setMedia(apiResponse.channel.getArticleList().get(i).getMedia());
                        p.setEncoded(apiResponse.channel.getArticleList().get(i).getEncoded());
                        p.setLink(apiResponse.channel.getArticleList().get(i).getLink());
                        m.setText(apiResponse.channel.getArticleList().get(i).getMediaContent().get(0).getText());
                        m.setCredit(apiResponse.channel.getArticleList().get(i).getMediaContent().get(0).getCredit());
                        m.setContent(apiResponse.channel.getArticleList().get(i).getMediaContent().get(0).getContent());
                        Details.add(p);
                        InnerDetails.add(m);
                    }


                    adapter = new MyListAdapter(Details, InnerDetails, MainActivity.this);
                    recyclerView.setHasFixedSize(true);
                    recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    recyclerView.setAdapter(adapter);


                    txtTitle.setText("Title " + apiResponse.channel.getTitle());
                    txtDescription.setText("Description " + apiResponse.channel.getChannelTitle());
                    txtLink.setText("Link " + apiResponse.channel.getDescription());

                } else {
                    System.out.println("Request Error :: " + response.errorBody());
                    Log.d("apiResponse ===>", response.errorBody().toString());
                }
            }

            @Override
            public void onFailure(Call<RssFeed> call, Throwable t) {
                if (call.isCanceled()) {
                    System.out.println("Call was cancelled forcefully");
                } else {
                    System.out.println("Network Error :: " + t.getLocalizedMessage());
                }
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
