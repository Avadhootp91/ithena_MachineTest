package com.example.ithenatechdemoapp.responseXml;

import org.simpleframework.xml.Attribute;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

//media:content
@Root(name = "content", strict = false)
public class RssMediaContent {

    @Element(name = "text", required = false)
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }



    @Element(name = "credit", required = false)
    private String credit;

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }


    //@Element(name = "content", required = false)
    @Attribute(name = "url")
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }



    @Override
    public String toString() {
        return "RssMediaContent [media:text=" + text +   ", media:credit=" + credit +    ", media:content=" + content + "]";
    }
}
