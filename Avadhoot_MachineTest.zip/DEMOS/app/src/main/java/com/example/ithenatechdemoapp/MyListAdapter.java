package com.example.ithenatechdemoapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ithenatechdemoapp.responseXml.RssItem;
import com.example.ithenatechdemoapp.responseXml.RssMediaContent;

import java.util.ArrayList;

public class MyListAdapter extends RecyclerView.Adapter<MyListAdapter.ViewHolder>{
    private MyListData[] listdata;
    private  Context ctx;
    ArrayList<RssItem> Details;
    ArrayList<RssMediaContent> InnerDetails;

    public MyListAdapter( ArrayList<RssItem> Details, ArrayList<RssMediaContent> InnerDetails,  Context ctx)
    {
        this.Details = Details;
        this.InnerDetails = InnerDetails;
        this.ctx = ctx;

    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.list_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.txtTitle.setText(Details.get(position).getTitle());
        holder.txtCategory.setText(Details.get(position).getCategory());
        holder.txtPubDate.setText(Details.get(position).getPubDate());
        holder.txtMediaKeyword.setText(Details.get(position).getMedia());

        holder.cardConstraint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(ctx, DetailScreen.class);
                intent.putExtra("title", Details.get(position).getTitle()); //you can name the keys whatever you like
                intent.putExtra("category", Details.get(position).getCategory()); //note that all these values have to be primitive (i.e boolean, int, double, String, etc.)
                intent.putExtra("pubdata", Details.get(position).getPubDate());
                intent.putExtra("description",  Details.get(position).getDescription());
                intent.putExtra("mediakeyword", Details.get(position).getMedia());
                intent.putExtra("contentencoded", Details.get(position).getEncoded());
                intent.putExtra("mediatext", InnerDetails.get(position).getText());
                intent.putExtra("mediacredit",InnerDetails.get(position).getCredit());
                intent.putExtra("mediacontent", InnerDetails.get(position).getContent());
                intent.putExtra("link", Details.get(position).getLink());
                ctx.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return Details.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txtTitle , txtPubDate, txtCategory, txtMediaKeyword;
        public ConstraintLayout cardConstraint;
        public ViewHolder(View itemView) {
            super(itemView);
            txtTitle = (TextView) itemView.findViewById(R.id.txtTitle);
            txtPubDate = (TextView) itemView.findViewById(R.id.txtPubDate);
            txtCategory = (TextView) itemView.findViewById(R.id.txtCategory);
            txtMediaKeyword = (TextView) itemView.findViewById(R.id.txtMediaKeyword);
            cardConstraint = (ConstraintLayout) itemView.findViewById(R.id.cardConstraint);
        }
    }
}