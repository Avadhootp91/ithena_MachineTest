package com.example.ithenatechdemoapp.responseXml;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RssService
{
    @GET("rss.xml")
    Call<RssFeed> getFeed();
}