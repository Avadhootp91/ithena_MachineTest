package com.example.ithenatechdemoapp.responseXml;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;
import org.simpleframework.xml.Root;

import java.util.List;

@Root(name = "channel", strict = false)
public class RssChannel
{

    @Element (name="title")
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    @Element (name="link")
    private String link;

    public String getChannelTitle() {
        return link;
    }

    public void setChannelTitle(String link) {
        this.link = link;
    }


    @Element (name="description")
    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @ElementList(inline = true, required = false)
    public List<RssItem> item;


    public List<RssItem> getArticleList() {
        return item;
    }

    public void setArticleList(List<RssItem> item) {
        this.item = item;
    }


    @Override
    public String toString() {
        return "Channel [link=" + link + ", item=" + item + "]";
   }
}