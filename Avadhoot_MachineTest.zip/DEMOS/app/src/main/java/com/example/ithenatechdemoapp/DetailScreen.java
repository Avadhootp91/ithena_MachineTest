package com.example.ithenatechdemoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

public class DetailScreen extends AppCompatActivity {

    private WebView webView;
    TextView txtTitle, txtDescription, txtCategory, txtPubDate, txtText, txtCredit, txtKeywords, txtEncoded;
    ImageView imgMedia;
    String title, category, pubdata, description, mediakeyword, contentencoded,
            mediatext, mediacredit, mediacontent, link;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_screen);

        title = getIntent().getExtras().getString("title");
        category = getIntent().getExtras().getString("category");
        pubdata = getIntent().getExtras().getString("pubdata");
        description = getIntent().getExtras().getString("description");
        mediakeyword = getIntent().getExtras().getString("mediakeyword");
        contentencoded = getIntent().getExtras().getString("contentencoded");
        mediatext = getIntent().getExtras().getString("mediatext");
        mediacredit = getIntent().getExtras().getString("mediacredit");
        mediacontent = getIntent().getExtras().getString("mediacontent");
        link = getIntent().getExtras().getString("link");




        txtTitle = (TextView) findViewById(R.id.txtTitle);
        txtDescription = (TextView) findViewById(R.id.txtDescription);
        txtCategory = (TextView) findViewById(R.id.txtCategory);
        txtPubDate = (TextView) findViewById(R.id.txtTotalCount);

        imgMedia = (ImageView) findViewById(R.id.imgMedia);

        txtText = (TextView) findViewById(R.id.txtText);
        txtCredit = (TextView) findViewById(R.id.txtCredit);
        txtKeywords = (TextView) findViewById(R.id.txtKeywords);
        txtEncoded = (TextView) findViewById(R.id.txtEncoded);

        txtTitle.setText(title);
        txtDescription.setText(description);
        txtCategory.setText(category);
        txtPubDate.setText(pubdata);
        txtEncoded.setText(contentencoded);

        txtText.setText(mediatext);
        txtCredit.setText(mediacredit);
        txtKeywords.setText(mediakeyword);


        webView = (WebView) findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(link);


        Picasso.get().load(mediacontent).memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE).networkPolicy(NetworkPolicy.NO_CACHE).
        placeholder(getApplication().getResources().getDrawable(R.drawable.ic_launcher_background)).error(getResources().getDrawable(R.drawable.ic_launcher_background)).into(imgMedia, new Callback() {
            @Override
            public void onSuccess() {

            }

            @Override
            public void onError(Exception e) {

            }
        });
    }
}
